import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdPosition,
  BannerAdSize
} from '@capacitor-community/admob';

// First build uses Google's official Android test banner.
// Change to false ONLY after the test build is verified and AdMob review/policies are clear.
const USE_TEST_ADS = true;
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/6300978111';
const PRODUCTION_BANNER_ID = 'ca-app-pub-1134522787126944/9534042299';

async function startBannerAd() {
  if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return;

  try {
    await AdMob.initialize();

    // Obtain consent information and show a consent form only when Google requires it.
    let consent = await AdMob.requestConsentInfo();
    if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
      consent = await AdMob.showConsentForm();
    }
    if (!consent.canRequestAds) {
      console.info('AdMob: consent does not currently allow ad requests.');
      return;
    }

    await AdMob.showBanner({
      adId: USE_TEST_ADS ? TEST_BANNER_ID : PRODUCTION_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: USE_TEST_ADS
    });
  } catch (error) {
    // Ad failure must never prevent the calculator or educational content from working.
    console.error('AdMob banner could not be displayed:', error);
  }
}

window.addEventListener('load', () => {
  // Delay slightly until the native WebView is ready.
  setTimeout(startBannerAd, 1200);
});
