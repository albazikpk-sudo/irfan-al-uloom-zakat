const fs = require('fs');
const path = require('path');
const { build } = require('esbuild');

const root = path.resolve(__dirname, '..');
const www = path.join(root, 'www');

(async () => {
  fs.mkdirSync(www, { recursive: true });
  for (const file of ['index.html', 'manifest.webmanifest', 'sw.js', 'privacy.html']) {
    fs.copyFileSync(path.join(root, file), path.join(www, file));
  }
  fs.cpSync(path.join(root, 'icons'), path.join(www, 'icons'), { recursive: true });
  await build({
    entryPoints: [path.join(root, 'src', 'admob.js')],
    outfile: path.join(www, 'admob.js'),
    bundle: true,
    platform: 'browser',
    format: 'esm',
    target: ['es2020'],
    minify: true
  });
  console.log('Web assets and bundled AdMob bridge prepared in www/.');
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
