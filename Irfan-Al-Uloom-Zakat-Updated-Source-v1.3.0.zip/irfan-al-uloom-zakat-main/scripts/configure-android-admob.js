const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const manifest = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const valuesDir = path.join(root, 'android', 'app', 'src', 'main', 'res', 'values');
const strings = path.join(valuesDir, 'strings.xml');
const appId = 'ca-app-pub-1134522787126944~8149525042';

if (!fs.existsSync(manifest)) {
  console.error('Android project not found. Run: npx cap add android');
  process.exit(1);
}
let xml = fs.readFileSync(manifest, 'utf8');
const meta = '<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id" />';
if (!xml.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  xml = xml.replace(/<application\b([^>]*)>/, (match) => `${match}\n        ${meta}`);
  fs.writeFileSync(manifest, xml);
}
fs.mkdirSync(valuesDir, { recursive: true });
let values = fs.existsSync(strings) ? fs.readFileSync(strings, 'utf8') : '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n';
if (values.includes('name="admob_app_id"')) {
  values = values.replace(/<string name="admob_app_id">.*?<\/string>/, `<string name="admob_app_id">${appId}</string>`);
} else {
  values = values.replace('</resources>', `    <string name="admob_app_id">${appId}</string>\n</resources>`);
}
fs.writeFileSync(strings, values);
console.log('AdMob App ID configured in AndroidManifest.xml and strings.xml.');
