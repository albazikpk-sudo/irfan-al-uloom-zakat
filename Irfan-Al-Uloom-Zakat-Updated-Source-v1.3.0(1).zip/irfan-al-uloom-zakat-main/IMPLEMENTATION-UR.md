# عرفان العلوم زکوٰۃ کیلکولیٹر — اپ ڈیٹ 1.3.0

## اس ورژن میں
- موجودہ کیلکولیٹر کا موجودہ حسابی کوڈ برقرار رکھا گیا ہے۔
- فقہِ حنفی کی عمومی رہنمائی کے آٹھ نئے موضوعاتی سلائیڈز شامل کیے گئے ہیں۔
- AdMob Capacitor 6 پلگ اِن کی تیاری شامل ہے۔
- اس سورس میں Production Banner Ad Unit فعال ہے؛ اشتہار کی حقیقی فراہمی AdMob اکاؤنٹ کی منظوری، رضامندی اور Ad Serving status پر منحصر ہے۔
- Privacy Policy میں AdMob اور تیسرے فریق کے ڈیٹا پراسیسنگ کی وضاحت شامل کی گئی ہے۔

## اہم علمی احتیاط
یہ سلائیڈز عوامی تعلیمی رہنمائی ہیں، کسی خاص معاملے کا فتویٰ نہیں۔ نصاب کے وزن کی تبدیلی، مخلوط اموال، قرض کی کٹوتی، تجارتی مال، اور مستحقین کی تطبیق میں جزئیات ہیں۔ اشاعت سے پہلے مستند حنفی دارالافتاء سے متن اور حوالہ جات کی نظرِ ثانی کروائیں۔ موجودہ کیلکولیٹر صرف نقدی سے درج کردہ قرض منہا کرکے 2.5% نکالتا ہے؛ یہ خودکار طور پر نصاب، حول، سونا، چاندی، تجارتی مال یا قرض کی شرعی اہلیت کی جانچ نہیں کرتا۔

## AdMob IDs
- App ID: `ca-app-pub-1134522787126944~8149525042`
- Banner Ad Unit ID: `ca-app-pub-1134522787126944/9534042299`

اس سورس میں `USE_TEST_ADS = false` ہے، اس لیے درج ذیل Production Banner Ad Unit استعمال ہوگا۔ Test Banner ID صرف محفوظ ٹیسٹنگ کے لیے کوڈ میں بطور متبادل رکھا گیا ہے۔ حقیقی اشتہارات فوراً ظاہر ہونا یقینی نہیں؛ AdMob میں ایپ کی تیاری/منظوری، Ad Serving status، رضامندی اور پالیسی تقاضے پورے ہونا ضروری ہیں۔ اپنے اشتہارات پر خود کلک نہ کریں۔

## Build / Android
Node.js 20 اور Java/Android build environment درکار ہے۔

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npm run android:admob
```

اگر `android` فولڈر پہلے سے بن چکا ہو تو `npx cap add android` دوبارہ نہ چلائیں؛ صرف:

```bash
npm install
npm run build
npx cap sync android
npm run android:admob
```

اس کے بعد Android Studio میں `android` فولڈر کھول کر Gradle sync اور AAB build کریں۔ Play Store کی موجودہ ایپ کو اپ ڈیٹ کرنے کے لیے وہی package name اور اصل upload/signing key استعمال کرنا ضروری ہے۔

## حقیقی اشتہارات کب فعال ہوں؟
1. پہلے signed test build میں test banner کی موجودگی اور ایپ کے درست چلنے کی تصدیق کریں۔
2. AdMob میں app review، ad serving status، privacy/consent اور Play Store listing کے تقاضے دیکھیں۔
3. اس ورژن میں `USE_TEST_ADS` پہلے ہی `false` ہے۔
4. `npm run build`, `npx cap sync android` اور نیا signed AAB بنائیں۔
5. Play Console میں نئی AAB اپلوڈ کرکے مطلوبہ ٹیسٹنگ/ریلیز مکمل کریں۔

## نوٹ
اصل Android فولڈر اس موصولہ ZIP میں موجود نہیں تھا۔ اس لیے اس سورس میں Android project کی generation اور AdMob manifest configuration کے scripts دیے گئے ہیں؛ اس ZIP کو اکیلے APK/AAB نہیں کہا جا سکتا۔ Native build اور حقیقی ڈیوائس پر ٹیسٹنگ ابھی باقی ہے۔


AdMob v1.3.1 correction: Capacitor AdMob v6 uses consent status checks; it does not provide `canRequestAds` (added in later plugin versions). The banner code now checks `AdmobConsentStatus.REQUIRED` before initialization and requests the Google test banner only when consent is not still required.
