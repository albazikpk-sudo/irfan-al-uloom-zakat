import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdPosition,
  BannerAdSize
} from '@capacitor-community/admob';

// Production AdMob banner is enabled. Verify app approval, consent, and ad serving before release.
const USE_TEST_ADS = false;
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/6300978111';
const PRODUCTION_BANNER_ID = 'ca-app-pub-1134522787126944/9534042299';

async function startBannerAd() {
  if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') {
    console.info('AdMob: native Android platform not detected.');
    return;
  }

  try {
    // Capacitor AdMob v6 does not expose consentInfo.canRequestAds.
    // Use the v6 consent status instead, then initialize and request the banner.
    let consentInfo = await AdMob.requestConsentInfo();

    if (
      consentInfo.status === AdmobConsentStatus.REQUIRED &&
      consentInfo.isConsentFormAvailable
    ) {
      consentInfo = await AdMob.showConsentForm();
    }

    // If consent is still required, do not request an ad.
    if (consentInfo.status === AdmobConsentStatus.REQUIRED) {
      console.info('AdMob: consent is still required; banner request skipped.');
      return;
    }

    await AdMob.initialize();

    await AdMob.showBanner({
      adId: USE_TEST_ADS ? TEST_BANNER_ID : PRODUCTION_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: USE_TEST_ADS
    });

    console.info('AdMob: banner request submitted.');
  } catch (error) {
    console.error('AdMob banner could not be displayed:', error);
  }
}

window.addEventListener('load', () => {
  // Wait until the Capacitor native view is ready.
  setTimeout(startBannerAd, 1200);
});
